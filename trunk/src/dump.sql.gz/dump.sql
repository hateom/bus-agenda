--
-- PostgreSQL database dump
--

SET client_encoding = 'UTF8';
SET standard_conforming_strings = off;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET escape_string_warning = off;

SET search_path = public, pg_catalog;

ALTER TABLE ONLY public.trasy DROP CONSTRAINT trasy_fk_id_przystanku_fkey;
ALTER TABLE ONLY public.trasy DROP CONSTRAINT trasy_fk_id_linii_fkey;
ALTER TABLE ONLY public.przystanki DROP CONSTRAINT przystanki_fk_id_ulica2_fkey;
ALTER TABLE ONLY public.przystanki DROP CONSTRAINT przystanki_fk_id_ulica1_fkey;
ALTER TABLE ONLY public.przesuniecia DROP CONSTRAINT przesuniecia_fk_id_przystanku_fkey;
ALTER TABLE ONLY public.przesuniecia DROP CONSTRAINT przesuniecia_fk_id_pory_fkey;
ALTER TABLE ONLY public.przesuniecia DROP CONSTRAINT przesuniecia_fk_id_linii_fkey;
ALTER TABLE ONLY public.odjazdy DROP CONSTRAINT odjazdy_fk_id_linii_fkey;
ALTER TABLE ONLY public.trasy DROP CONSTRAINT trasy_pkey;
ALTER TABLE ONLY public.przystanki DROP CONSTRAINT przystanki_pkey;
ALTER TABLE ONLY public.przesuniecia DROP CONSTRAINT przesuniecia_pkey;
ALTER TABLE ONLY public.pory DROP CONSTRAINT pory_pkey;
ALTER TABLE ONLY public.odjazdy DROP CONSTRAINT odjazdy_pkey;
ALTER TABLE ONLY public.linie DROP CONSTRAINT linie_pkey;
ALTER TABLE ONLY public.ulice_d DROP CONSTRAINT dict_ulice_pkey;
ALTER TABLE public.ulice_d ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.trasy ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.przystanki ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.przesuniecia ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.pory ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.odjazdy ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.linie ALTER COLUMN id DROP DEFAULT;
DROP SEQUENCE public.trasy_id_seq;
DROP TABLE public.trasy;
DROP VIEW public.timetable_view;
DROP TABLE public.timetable_pop;
DROP TABLE public.timetable_morning;
DROP SEQUENCE public.przystanki_id_seq;
DROP TABLE public.przystanki;
DROP VIEW public.przesuniecia_rano;
DROP VIEW public.przesuniecia_pop;
DROP SEQUENCE public.przesuniecia_numer_kolejny_seq;
DROP SEQUENCE public.przesuniecia_id_seq;
DROP TABLE public.przesuniecia;
DROP SEQUENCE public.pory_id_seq;
DROP TABLE public.pory;
DROP SEQUENCE public.odjazdy_id_seq;
DROP TABLE public.odjazdy;
DROP SEQUENCE public.linie_id_seq;
DROP TABLE public.linie;
DROP SEQUENCE public.dict_ulice_id_seq;
DROP TABLE public.ulice_d;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'Standard public schema';


SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: ulice_d; Type: TABLE; Schema: public; Owner: busag; Tablespace: 
--

CREATE TABLE ulice_d (
    id integer NOT NULL,
    nazwa character varying(255) NOT NULL
);


ALTER TABLE public.ulice_d OWNER TO busag;

--
-- Name: TABLE ulice_d; Type: COMMENT; Schema: public; Owner: busag
--

COMMENT ON TABLE ulice_d IS 'Słownik ulic';


--
-- Name: COLUMN ulice_d.id; Type: COMMENT; Schema: public; Owner: busag
--

COMMENT ON COLUMN ulice_d.id IS 'Klucz główny';


--
-- Name: COLUMN ulice_d.nazwa; Type: COMMENT; Schema: public; Owner: busag
--

COMMENT ON COLUMN ulice_d.nazwa IS 'Nazwa ulicy';


--
-- Name: dict_ulice_id_seq; Type: SEQUENCE; Schema: public; Owner: busag
--

CREATE SEQUENCE dict_ulice_id_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.dict_ulice_id_seq OWNER TO busag;

--
-- Name: dict_ulice_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: busag
--

ALTER SEQUENCE dict_ulice_id_seq OWNED BY ulice_d.id;


--
-- Name: dict_ulice_id_seq; Type: SEQUENCE SET; Schema: public; Owner: busag
--

SELECT pg_catalog.setval('dict_ulice_id_seq', 6, true);


--
-- Name: linie; Type: TABLE; Schema: public; Owner: busag; Tablespace: 
--

CREATE TABLE linie (
    id integer NOT NULL,
    numer integer NOT NULL,
    typ integer NOT NULL,
    opis character varying(200)
);


ALTER TABLE public.linie OWNER TO busag;

--
-- Name: linie_id_seq; Type: SEQUENCE; Schema: public; Owner: busag
--

CREATE SEQUENCE linie_id_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.linie_id_seq OWNER TO busag;

--
-- Name: linie_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: busag
--

ALTER SEQUENCE linie_id_seq OWNED BY linie.id;


--
-- Name: linie_id_seq; Type: SEQUENCE SET; Schema: public; Owner: busag
--

SELECT pg_catalog.setval('linie_id_seq', 3, true);


--
-- Name: odjazdy; Type: TABLE; Schema: public; Owner: busag; Tablespace: 
--

CREATE TABLE odjazdy (
    id integer NOT NULL,
    linie_id integer NOT NULL,
    kierunek integer NOT NULL,
    godzina time without time zone
);


ALTER TABLE public.odjazdy OWNER TO busag;

--
-- Name: TABLE odjazdy; Type: COMMENT; Schema: public; Owner: busag
--

COMMENT ON TABLE odjazdy IS 'Odjazdy autobusow';


--
-- Name: COLUMN odjazdy.godzina; Type: COMMENT; Schema: public; Owner: busag
--

COMMENT ON COLUMN odjazdy.godzina IS 'Godzina odjazdu';


--
-- Name: odjazdy_id_seq; Type: SEQUENCE; Schema: public; Owner: busag
--

CREATE SEQUENCE odjazdy_id_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.odjazdy_id_seq OWNER TO busag;

--
-- Name: odjazdy_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: busag
--

ALTER SEQUENCE odjazdy_id_seq OWNED BY odjazdy.id;


--
-- Name: odjazdy_id_seq; Type: SEQUENCE SET; Schema: public; Owner: busag
--

SELECT pg_catalog.setval('odjazdy_id_seq', 3, true);


--
-- Name: pory; Type: TABLE; Schema: public; Owner: busag; Tablespace: 
--

CREATE TABLE pory (
    id integer NOT NULL,
    rozp time without time zone NOT NULL,
    zakoncz time without time zone NOT NULL,
    opis character varying(64) NOT NULL
);


ALTER TABLE public.pory OWNER TO busag;

--
-- Name: TABLE pory; Type: COMMENT; Schema: public; Owner: busag
--

COMMENT ON TABLE pory IS 'Table pór dnia';


--
-- Name: COLUMN pory.id; Type: COMMENT; Schema: public; Owner: busag
--

COMMENT ON COLUMN pory.id IS 'ID';


--
-- Name: COLUMN pory.rozp; Type: COMMENT; Schema: public; Owner: busag
--

COMMENT ON COLUMN pory.rozp IS 'Pora rozpoczęcia';


--
-- Name: COLUMN pory.zakoncz; Type: COMMENT; Schema: public; Owner: busag
--

COMMENT ON COLUMN pory.zakoncz IS 'Godzina zakończenia pory';


--
-- Name: COLUMN pory.opis; Type: COMMENT; Schema: public; Owner: busag
--

COMMENT ON COLUMN pory.opis IS 'Opis';


--
-- Name: pory_id_seq; Type: SEQUENCE; Schema: public; Owner: busag
--

CREATE SEQUENCE pory_id_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.pory_id_seq OWNER TO busag;

--
-- Name: pory_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: busag
--

ALTER SEQUENCE pory_id_seq OWNED BY pory.id;


--
-- Name: pory_id_seq; Type: SEQUENCE SET; Schema: public; Owner: busag
--

SELECT pg_catalog.setval('pory_id_seq', 8, true);


--
-- Name: przesuniecia; Type: TABLE; Schema: public; Owner: busag; Tablespace: 
--

CREATE TABLE przesuniecia (
    id integer NOT NULL,
    linie_id integer NOT NULL,
    przystanki_id integer NOT NULL,
    numer_kolejny integer DEFAULT 0 NOT NULL,
    "offset" interval NOT NULL,
    pory_id integer NOT NULL
);


ALTER TABLE public.przesuniecia OWNER TO busag;

--
-- Name: COLUMN przesuniecia.id; Type: COMMENT; Schema: public; Owner: busag
--

COMMENT ON COLUMN przesuniecia.id IS 'Klucz główny';


--
-- Name: COLUMN przesuniecia.linie_id; Type: COMMENT; Schema: public; Owner: busag
--

COMMENT ON COLUMN przesuniecia.linie_id IS 'klucz obcy na tabelę linie (ID_LINII)';


--
-- Name: COLUMN przesuniecia.przystanki_id; Type: COMMENT; Schema: public; Owner: busag
--

COMMENT ON COLUMN przesuniecia.przystanki_id IS 'Klucz obcy na tabelę przystanki (ID_PRZYSTANKU)';


--
-- Name: COLUMN przesuniecia.numer_kolejny; Type: COMMENT; Schema: public; Owner: busag
--

COMMENT ON COLUMN przesuniecia.numer_kolejny IS 'Kolejność przystanku';


--
-- Name: COLUMN przesuniecia.pory_id; Type: COMMENT; Schema: public; Owner: busag
--

COMMENT ON COLUMN przesuniecia.pory_id IS 'klucz obcy na tabelę pór';


--
-- Name: przesuniecia_id_seq; Type: SEQUENCE; Schema: public; Owner: busag
--

CREATE SEQUENCE przesuniecia_id_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.przesuniecia_id_seq OWNER TO busag;

--
-- Name: przesuniecia_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: busag
--

ALTER SEQUENCE przesuniecia_id_seq OWNED BY przesuniecia.id;


--
-- Name: przesuniecia_id_seq; Type: SEQUENCE SET; Schema: public; Owner: busag
--

SELECT pg_catalog.setval('przesuniecia_id_seq', 15, true);


--
-- Name: przesuniecia_numer_kolejny_seq; Type: SEQUENCE; Schema: public; Owner: busag
--

CREATE SEQUENCE przesuniecia_numer_kolejny_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.przesuniecia_numer_kolejny_seq OWNER TO busag;

--
-- Name: przesuniecia_numer_kolejny_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: busag
--

ALTER SEQUENCE przesuniecia_numer_kolejny_seq OWNED BY przesuniecia.numer_kolejny;


--
-- Name: przesuniecia_numer_kolejny_seq; Type: SEQUENCE SET; Schema: public; Owner: busag
--

SELECT pg_catalog.setval('przesuniecia_numer_kolejny_seq', 7, true);


--
-- Name: przesuniecia_pop; Type: VIEW; Schema: public; Owner: busag
--

CREATE VIEW przesuniecia_pop AS
    SELECT przesuniecia.id, przesuniecia.linie_id, przesuniecia.przystanki_id, przesuniecia.numer_kolejny, przesuniecia."offset", przesuniecia.pory_id FROM przesuniecia WHERE (przesuniecia.pory_id = 2);


ALTER TABLE public.przesuniecia_pop OWNER TO busag;

--
-- Name: przesuniecia_rano; Type: VIEW; Schema: public; Owner: busag
--

CREATE VIEW przesuniecia_rano AS
    SELECT przesuniecia.id, przesuniecia.linie_id, przesuniecia.przystanki_id, przesuniecia.numer_kolejny, przesuniecia."offset", przesuniecia.pory_id FROM przesuniecia WHERE (przesuniecia.pory_id = 1);


ALTER TABLE public.przesuniecia_rano OWNER TO busag;

--
-- Name: przystanki; Type: TABLE; Schema: public; Owner: busag; Tablespace: 
--

CREATE TABLE przystanki (
    id integer NOT NULL,
    nazwa character varying NOT NULL,
    ulice_d_id integer,
    fk_id_ulica1 integer
);


ALTER TABLE public.przystanki OWNER TO busag;

--
-- Name: COLUMN przystanki.ulice_d_id; Type: COMMENT; Schema: public; Owner: busag
--

COMMENT ON COLUMN przystanki.ulice_d_id IS 'Klucz obcy (opcjonalny) wskazujący na ulicę drugą';


--
-- Name: przystanki_id_seq; Type: SEQUENCE; Schema: public; Owner: busag
--

CREATE SEQUENCE przystanki_id_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.przystanki_id_seq OWNER TO busag;

--
-- Name: przystanki_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: busag
--

ALTER SEQUENCE przystanki_id_seq OWNED BY przystanki.id;


--
-- Name: przystanki_id_seq; Type: SEQUENCE SET; Schema: public; Owner: busag
--

SELECT pg_catalog.setval('przystanki_id_seq', 6, true);


--
-- Name: timetable_morning; Type: TABLE; Schema: public; Owner: busag; Tablespace: 
--

CREATE TABLE timetable_morning (
    linia integer,
    numerycznie integer,
    numer_kolejny integer,
    przystanek_id integer,
    przystanek character varying,
    pory_id integer,
    odj time without time zone,
    odj_id integer
);


ALTER TABLE public.timetable_morning OWNER TO busag;

--
-- Name: timetable_pop; Type: TABLE; Schema: public; Owner: busag; Tablespace: 
--

CREATE TABLE timetable_pop (
    linia integer,
    numerycznie integer,
    numer_kolejny integer,
    przystanek_id integer,
    przystanek character varying,
    pory_id integer,
    odj time without time zone,
    odj_id integer
);


ALTER TABLE public.timetable_pop OWNER TO busag;

--
-- Name: timetable_view; Type: VIEW; Schema: public; Owner: busag
--

CREATE VIEW timetable_view AS
    SELECT odjazdy.linie_id AS linia, (SELECT linie.numer FROM linie WHERE (linie.id = odjazdy.linie_id)) AS numerycznie, przesuniecia.numer_kolejny, przystanki.id AS przystanek_id, przystanki.nazwa AS przystanek, przesuniecia.pory_id, (przesuniecia."offset" + odjazdy.godzina) AS odj, odjazdy.id AS odj_id FROM ((przystanki JOIN przesuniecia ON ((przesuniecia.przystanki_id = przystanki.id))) JOIN odjazdy ON ((odjazdy.linie_id = przesuniecia.linie_id))) ORDER BY przesuniecia.numer_kolejny, przesuniecia.pory_id;


ALTER TABLE public.timetable_view OWNER TO busag;

--
-- Name: VIEW timetable_view; Type: COMMENT; Schema: public; Owner: busag
--

COMMENT ON VIEW timetable_view IS 'Widok na rozkład ;)';


--
-- Name: trasy; Type: TABLE; Schema: public; Owner: busag; Tablespace: 
--

CREATE TABLE trasy (
    id integer NOT NULL,
    linie_id integer,
    przystanki_id integer,
    numer_kolejny integer
);


ALTER TABLE public.trasy OWNER TO busag;

--
-- Name: trasy_id_seq; Type: SEQUENCE; Schema: public; Owner: busag
--

CREATE SEQUENCE trasy_id_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.trasy_id_seq OWNER TO busag;

--
-- Name: trasy_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: busag
--

ALTER SEQUENCE trasy_id_seq OWNED BY trasy.id;


--
-- Name: trasy_id_seq; Type: SEQUENCE SET; Schema: public; Owner: busag
--

SELECT pg_catalog.setval('trasy_id_seq', 6, true);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: busag
--

ALTER TABLE linie ALTER COLUMN id SET DEFAULT nextval('linie_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: busag
--

ALTER TABLE odjazdy ALTER COLUMN id SET DEFAULT nextval('odjazdy_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: busag
--

ALTER TABLE pory ALTER COLUMN id SET DEFAULT nextval('pory_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: busag
--

ALTER TABLE przesuniecia ALTER COLUMN id SET DEFAULT nextval('przesuniecia_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: busag
--

ALTER TABLE przystanki ALTER COLUMN id SET DEFAULT nextval('przystanki_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: busag
--

ALTER TABLE trasy ALTER COLUMN id SET DEFAULT nextval('trasy_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: busag
--

ALTER TABLE ulice_d ALTER COLUMN id SET DEFAULT nextval('dict_ulice_id_seq'::regclass);


--
-- Data for Name: linie; Type: TABLE DATA; Schema: public; Owner: busag
--

INSERT INTO linie VALUES (1, 144, 0, 'Rżąka-PBW');
INSERT INTO linie VALUES (2, 173, 0, 'fff');
INSERT INTO linie VALUES (3, 194, 1, 'Stacja A- Stacja B');


--
-- Data for Name: odjazdy; Type: TABLE DATA; Schema: public; Owner: busag
--

INSERT INTO odjazdy VALUES (1, 1, 0, '14:21:00');
INSERT INTO odjazdy VALUES (2, 2, 0, '15:00:00');
INSERT INTO odjazdy VALUES (3, 1, 0, '12:10:00');


--
-- Data for Name: pory; Type: TABLE DATA; Schema: public; Owner: busag
--

INSERT INTO pory VALUES (2, '12:00:00', '17:59:00', 'Południe');
INSERT INTO pory VALUES (1, '05:00:00', '11:59:00', 'Rano');
INSERT INTO pory VALUES (3, '18:00:00', '04:59:00', 'Wieczór/NOC');


--
-- Data for Name: przesuniecia; Type: TABLE DATA; Schema: public; Owner: busag
--

INSERT INTO przesuniecia VALUES (8, 1, 1, 0, '00:00:00', 1);
INSERT INTO przesuniecia VALUES (10, 1, 3, 2, '00:05:00', 1);
INSERT INTO przesuniecia VALUES (9, 1, 2, 1, '00:01:00', 1);
INSERT INTO przesuniecia VALUES (11, 1, 4, 3, '00:45:00', 1);
INSERT INTO przesuniecia VALUES (5, 2, 5, 0, '00:00:00', 2);
INSERT INTO przesuniecia VALUES (4, 1, 4, 3, '00:54:00', 2);
INSERT INTO przesuniecia VALUES (6, 2, 6, 2, '00:55:00', 2);
INSERT INTO przesuniecia VALUES (7, 2, 3, 1, '00:23:00', 2);
INSERT INTO przesuniecia VALUES (3, 1, 3, 2, '00:06:00', 2);
INSERT INTO przesuniecia VALUES (2, 1, 2, 1, '00:02:00', 2);
INSERT INTO przesuniecia VALUES (1, 1, 1, 0, '00:00:00', 2);
INSERT INTO przesuniecia VALUES (12, 2, 3, 1, '00:20:00', 1);
INSERT INTO przesuniecia VALUES (14, 2, 5, 0, '00:00:00', 1);
INSERT INTO przesuniecia VALUES (15, 2, 6, 2, '00:40:00', 1);


--
-- Data for Name: przystanki; Type: TABLE DATA; Schema: public; Owner: busag
--

INSERT INTO przystanki VALUES (1, 'Rzaka', NULL, 1);
INSERT INTO przystanki VALUES (6, 'Azory', 1, 2);
INSERT INTO przystanki VALUES (5, 'Biezanow Nowy', 2, 3);
INSERT INTO przystanki VALUES (4, 'Pradnik', NULL, 4);
INSERT INTO przystanki VALUES (3, 'AGH', NULL, 5);
INSERT INTO przystanki VALUES (2, 'Prokocim Szpital', NULL, 6);


--
-- Data for Name: timetable_morning; Type: TABLE DATA; Schema: public; Owner: busag
--

INSERT INTO timetable_morning VALUES (1, 144, 0, 1, 'Rzaka', 1, '12:10:00', 3);
INSERT INTO timetable_morning VALUES (1, 144, 0, 1, 'Rzaka', 1, '14:21:00', 1);
INSERT INTO timetable_morning VALUES (2, 173, 0, 5, 'Biezanow Nowy', 1, '15:00:00', 2);
INSERT INTO timetable_morning VALUES (2, 173, 1, 3, 'AGH', 1, '15:20:00', 2);
INSERT INTO timetable_morning VALUES (1, 144, 1, 2, 'Prokocim Szpital', 1, '14:22:00', 1);
INSERT INTO timetable_morning VALUES (1, 144, 1, 2, 'Prokocim Szpital', 1, '12:11:00', 3);
INSERT INTO timetable_morning VALUES (1, 144, 2, 3, 'AGH', 1, '14:26:00', 1);
INSERT INTO timetable_morning VALUES (2, 173, 2, 6, 'Azory', 1, '15:40:00', 2);
INSERT INTO timetable_morning VALUES (1, 144, 2, 3, 'AGH', 1, '12:15:00', 3);
INSERT INTO timetable_morning VALUES (1, 144, 3, 4, 'Pradnik', 1, '15:06:00', 1);
INSERT INTO timetable_morning VALUES (1, 144, 3, 4, 'Pradnik', 1, '12:55:00', 3);


--
-- Data for Name: timetable_pop; Type: TABLE DATA; Schema: public; Owner: busag
--

INSERT INTO timetable_pop VALUES (1, 144, 0, 1, 'Rzaka', 2, '12:10:00', 3);
INSERT INTO timetable_pop VALUES (1, 144, 0, 1, 'Rzaka', 2, '14:21:00', 1);
INSERT INTO timetable_pop VALUES (2, 173, 0, 5, 'Biezanow Nowy', 2, '15:00:00', 2);
INSERT INTO timetable_pop VALUES (2, 173, 1, 3, 'AGH', 2, '15:23:00', 2);
INSERT INTO timetable_pop VALUES (1, 144, 1, 2, 'Prokocim Szpital', 2, '14:23:00', 1);
INSERT INTO timetable_pop VALUES (1, 144, 1, 2, 'Prokocim Szpital', 2, '12:12:00', 3);
INSERT INTO timetable_pop VALUES (1, 144, 2, 3, 'AGH', 2, '14:27:00', 1);
INSERT INTO timetable_pop VALUES (2, 173, 2, 6, 'Azory', 2, '15:55:00', 2);
INSERT INTO timetable_pop VALUES (1, 144, 2, 3, 'AGH', 2, '12:16:00', 3);
INSERT INTO timetable_pop VALUES (1, 144, 3, 4, 'Pradnik', 2, '15:15:00', 1);
INSERT INTO timetable_pop VALUES (1, 144, 3, 4, 'Pradnik', 2, '13:04:00', 3);


--
-- Data for Name: trasy; Type: TABLE DATA; Schema: public; Owner: busag
--

INSERT INTO trasy VALUES (1, 1, 1, NULL);
INSERT INTO trasy VALUES (2, 1, 2, NULL);
INSERT INTO trasy VALUES (3, 1, 3, NULL);
INSERT INTO trasy VALUES (4, 1, 4, NULL);
INSERT INTO trasy VALUES (5, 2, 5, NULL);
INSERT INTO trasy VALUES (6, 2, 6, NULL);


--
-- Data for Name: ulice_d; Type: TABLE DATA; Schema: public; Owner: busag
--

INSERT INTO ulice_d VALUES (1, 'Wielicka');
INSERT INTO ulice_d VALUES (2, 'Teligi');
INSERT INTO ulice_d VALUES (3, 'Czarnowiejska');
INSERT INTO ulice_d VALUES (4, 'Białoprądnicka');
INSERT INTO ulice_d VALUES (5, 'Aleksandry');
INSERT INTO ulice_d VALUES (6, 'Azorska');


--
-- Name: dict_ulice_pkey; Type: CONSTRAINT; Schema: public; Owner: busag; Tablespace: 
--

ALTER TABLE ONLY ulice_d
    ADD CONSTRAINT dict_ulice_pkey PRIMARY KEY (id);


--
-- Name: linie_pkey; Type: CONSTRAINT; Schema: public; Owner: busag; Tablespace: 
--

ALTER TABLE ONLY linie
    ADD CONSTRAINT linie_pkey PRIMARY KEY (id);


--
-- Name: odjazdy_pkey; Type: CONSTRAINT; Schema: public; Owner: busag; Tablespace: 
--

ALTER TABLE ONLY odjazdy
    ADD CONSTRAINT odjazdy_pkey PRIMARY KEY (id);


--
-- Name: pory_pkey; Type: CONSTRAINT; Schema: public; Owner: busag; Tablespace: 
--

ALTER TABLE ONLY pory
    ADD CONSTRAINT pory_pkey PRIMARY KEY (id);


--
-- Name: przesuniecia_pkey; Type: CONSTRAINT; Schema: public; Owner: busag; Tablespace: 
--

ALTER TABLE ONLY przesuniecia
    ADD CONSTRAINT przesuniecia_pkey PRIMARY KEY (id);


--
-- Name: przystanki_pkey; Type: CONSTRAINT; Schema: public; Owner: busag; Tablespace: 
--

ALTER TABLE ONLY przystanki
    ADD CONSTRAINT przystanki_pkey PRIMARY KEY (id);


--
-- Name: trasy_pkey; Type: CONSTRAINT; Schema: public; Owner: busag; Tablespace: 
--

ALTER TABLE ONLY trasy
    ADD CONSTRAINT trasy_pkey PRIMARY KEY (id);


--
-- Name: odjazdy_fk_id_linii_fkey; Type: FK CONSTRAINT; Schema: public; Owner: busag
--

ALTER TABLE ONLY odjazdy
    ADD CONSTRAINT odjazdy_fk_id_linii_fkey FOREIGN KEY (linie_id) REFERENCES linie(id);


--
-- Name: przesuniecia_fk_id_linii_fkey; Type: FK CONSTRAINT; Schema: public; Owner: busag
--

ALTER TABLE ONLY przesuniecia
    ADD CONSTRAINT przesuniecia_fk_id_linii_fkey FOREIGN KEY (linie_id) REFERENCES linie(id);


--
-- Name: przesuniecia_fk_id_pory_fkey; Type: FK CONSTRAINT; Schema: public; Owner: busag
--

ALTER TABLE ONLY przesuniecia
    ADD CONSTRAINT przesuniecia_fk_id_pory_fkey FOREIGN KEY (pory_id) REFERENCES pory(id);


--
-- Name: przesuniecia_fk_id_przystanku_fkey; Type: FK CONSTRAINT; Schema: public; Owner: busag
--

ALTER TABLE ONLY przesuniecia
    ADD CONSTRAINT przesuniecia_fk_id_przystanku_fkey FOREIGN KEY (przystanki_id) REFERENCES przystanki(id);


--
-- Name: przystanki_fk_id_ulica1_fkey; Type: FK CONSTRAINT; Schema: public; Owner: busag
--

ALTER TABLE ONLY przystanki
    ADD CONSTRAINT przystanki_fk_id_ulica1_fkey FOREIGN KEY (fk_id_ulica1) REFERENCES ulice_d(id);


--
-- Name: przystanki_fk_id_ulica2_fkey; Type: FK CONSTRAINT; Schema: public; Owner: busag
--

ALTER TABLE ONLY przystanki
    ADD CONSTRAINT przystanki_fk_id_ulica2_fkey FOREIGN KEY (ulice_d_id) REFERENCES ulice_d(id);


--
-- Name: trasy_fk_id_linii_fkey; Type: FK CONSTRAINT; Schema: public; Owner: busag
--

ALTER TABLE ONLY trasy
    ADD CONSTRAINT trasy_fk_id_linii_fkey FOREIGN KEY (linie_id) REFERENCES linie(id);


--
-- Name: trasy_fk_id_przystanku_fkey; Type: FK CONSTRAINT; Schema: public; Owner: busag
--

ALTER TABLE ONLY trasy
    ADD CONSTRAINT trasy_fk_id_przystanku_fkey FOREIGN KEY (przystanki_id) REFERENCES przystanki(id);


--
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

