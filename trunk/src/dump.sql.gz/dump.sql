--
-- PostgreSQL database dump
--

SET client_encoding = 'UTF8';
SET standard_conforming_strings = off;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET escape_string_warning = off;

SET search_path = public, pg_catalog;

--
-- Name: dict_ulice_id_seq; Type: SEQUENCE SET; Schema: public; Owner: busag
--

SELECT pg_catalog.setval('dict_ulice_id_seq', 24, true);


--
-- Name: odjazdy_id_seq; Type: SEQUENCE SET; Schema: public; Owner: busag
--

SELECT pg_catalog.setval('odjazdy_id_seq', 22, true);


--
-- Name: pory_id_seq; Type: SEQUENCE SET; Schema: public; Owner: busag
--

SELECT pg_catalog.setval('pory_id_seq', 8, true);


--
-- Name: przesuniecia_id_seq; Type: SEQUENCE SET; Schema: public; Owner: busag
--

SELECT pg_catalog.setval('przesuniecia_id_seq', 90, true);


--
-- Name: przystanki_id_seq; Type: SEQUENCE SET; Schema: public; Owner: busag
--

SELECT pg_catalog.setval('przystanki_id_seq', 16, true);


--
-- Name: trasy_id_seq; Type: SEQUENCE SET; Schema: public; Owner: busag
--

SELECT pg_catalog.setval('trasy_id_seq', 60, true);


--
-- Data for Name: linie; Type: TABLE DATA; Schema: public; Owner: busag
--

COPY linie (numer, typ, opis) FROM stdin;
173	0	fff
194	1	Stacja A- Stacja B
321	0	Test
144	0	Rżąka-PBW
312	0	213
273	0	
666	0	To Hell
192	0	Lotniskowy
\.


--
-- Data for Name: odjazdy; Type: TABLE DATA; Schema: public; Owner: busag
--

COPY odjazdy (id, linie_id, godzina, kierunek) FROM stdin;
4	194	17:45:00	0
8	173	08:00:00	0
7	173	17:00:00	0
6	173	16:00:00	0
2	173	15:00:00	0
3	144	12:10:00	0
1	144	14:21:00	0
5	194	08:23:00	0
9	144	15:26:00	1
10	194	19:15:00	1
11	173	14:35:00	1
12	194	10:00:00	0
19	192	12:01:00	0
20	192	18:02:00	0
21	192	14:00:00	1
22	192	22:00:00	1
\.


--
-- Data for Name: pory; Type: TABLE DATA; Schema: public; Owner: busag
--

COPY pory (id, rozp, zakoncz, opis) FROM stdin;
2	12:00:00	17:59:00	Południe
1	05:00:00	11:59:00	Rano
3	18:00:00	04:59:00	Wieczór/NOC
\.


--
-- Data for Name: przesuniecia; Type: TABLE DATA; Schema: public; Owner: busag
--

COPY przesuniecia (id, "offset", trasy_id, powrotna) FROM stdin;
3	00:30:00	1	1
5	00:20:00	2	1
9	00:00:00	4	1
7	00:10:00	3	1
17	00:00:00	7	0
18	00:15:00	7	1
19	00:04:00	8	0
20	00:11:00	8	1
21	00:10:00	9	0
22	00:05:00	9	1
23	00:15:00	10	0
2	00:00:00	1	0
4	00:10:00	2	0
6	00:20:00	3	0
8	00:30:00	4	0
10	00:00:00	5	0
12	00:15:00	6	0
15	00:17:00	11	0
16	00:00:00	11	1
13	00:02:00	6	1
11	00:17:00	5	1
26	00:00:00	10	1
27	00:00:00	30	0
28	00:00:00	30	1
29	00:00:00	31	0
30	00:00:00	31	1
31	00:00:00	32	0
32	00:00:00	32	1
47	00:00:00	39	0
48	00:00:00	39	1
49	00:00:00	40	0
50	00:00:00	40	1
51	00:00:00	41	0
52	00:00:00	41	1
53	00:00:00	42	0
54	00:00:00	42	1
55	00:00:00	43	0
56	00:00:00	43	1
57	00:00:00	44	0
58	00:00:00	44	1
75	00:00:00	53	0
76	00:00:00	53	1
77	00:00:00	54	0
78	00:00:00	54	1
79	00:00:00	55	0
80	00:00:00	55	1
81	00:00:00	56	0
82	00:00:00	56	1
83	00:00:00	57	0
84	00:00:00	57	1
85	00:00:00	58	0
86	00:00:00	58	1
87	00:00:00	59	0
89	00:20:00	60	0
90	00:00:00	60	1
88	00:20:00	59	1
\.


--
-- Data for Name: przystanki; Type: TABLE DATA; Schema: public; Owner: busag
--

COPY przystanki (id, nazwa, ulica1_id, ulica2_id) FROM stdin;
6	Azory	1	2
7	Bronowice Małe	1	2
2	Prokocim Szpital	2	6
1	Rżąka	4	1
4	Prądnik	5	4
3	AGH	1	6
5	Bieżanów Stary	2	10
8	Nowosądecka	6	7
14	Przyst1	7	10
15	Teligi	1	11
16	Witosa	8	12
\.


--
-- Data for Name: trasy; Type: TABLE DATA; Schema: public; Owner: busag
--

COPY trasy (id, linie_id, przystanki_id, numer_kolejny) FROM stdin;
5	173	5	0
6	173	6	1
7	194	1	0
8	194	2	1
9	194	5	2
10	194	6	3
11	173	7	2
15	321	3	0
16	321	5	1
17	321	8	2
18	321	1	3
1	144	5	0
2	144	2	1
3	144	8	2
4	144	3	3
30	312	3	0
31	312	5	1
32	312	7	2
39	273	3	0
40	273	5	1
41	273	7	2
42	273	8	3
43	273	1	4
44	273	2	5
53	666	3	0
54	666	6	1
55	666	5	2
56	666	8	3
57	666	2	4
58	666	1	5
59	192	6	0
60	192	14	1
\.


--
-- Data for Name: ulice_d; Type: TABLE DATA; Schema: public; Owner: busag
--

COPY ulice_d (id, nazwa) FROM stdin;
2	Teligi
4	Białoprądnicka
6	Azorska
8	Witosa
7	Stara
1	Oświęcimska
11	Nawojki
12	Wielicka
10	Bartłomieja
5	Aleksandry
13	Brzozowa
16	Południowa
17	Sarska
18	Dworcowa
19	Czarnowiejska
21	Mazowiecka
22	Czysta
23	Kolejowa
24	Rezydencka
\.


--
-- PostgreSQL database dump complete
--

